def count_in_list(list, to_find):
    return list.count(to_find)
